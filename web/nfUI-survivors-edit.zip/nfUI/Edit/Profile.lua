-- The edit's default profile, applied once, and the layout's fit to the screen.
local PROFILE_VERSION=17
local SPOTS={
    actionBar={674,255},xp={674,282},player={674,292},playerAuras={674,318},
    target={1189,292},targetDebuffs={1189,318},
    minimap={1840,655},dpsMeter={1836,27},tooltip={1790,190},
    chat1={21,21},chatInput={8,177},
    -- Hidden unless switched on; without a spot here it would keep a position made for another screen.
    runPanel={2028,196},
}
-- The old game's places, on the same 3440x1440 basis: your frame and the target's in the top left, the debuffs
-- under the target, the bar and the experience at the bottom centre. The buffs go beside the minimap.
local CLASSIC={player={40,795},target={330,795},targetDebuffs={330,762},actionBar={881,8},xp={882,46}}
-- Classic is also the old game's sizes: larger frames with portraits, larger buttons, a wider experience strip.
local CLASSIC_SIZES={
    player={width=200,height=24,portrait=40,powerHeight=4,nameFont=13,valueFont=13},
    target={width=200,height=24,portrait=40,powerHeight=4,nameFont=13,valueFont=13},
    playerStyle={showPortrait=true},targetStyle={showPortrait=true},
    action={size=34,gap=3,hotkeyFont=10,cooldownFont=14,countFont=11},
    xp={width=244,height=6},
    auras={size=26,gap=2,timeFont=11,stackFont=11},debuffs={size=24,gap=2,stackFont=11},
}
local function SizesOf(db)
    local copy={}
    for name,values in pairs(CLASSIC_SIZES) do
        copy[name]={}
        for key in pairs(values) do if type(db[name])=="table" then copy[name][key]=db[name][key] end end
    end
    return copy
end
local function PutSizes(db,sizes)
    for name,values in pairs(sizes or {}) do
        if type(db[name])~="table" then db[name]={} end
        for key,value in pairs(values) do db[name][key]=value end
    end
end
local CLASSIC_CENTERED={actionBar=true,xp=true}
local function Merge(target,values)
    if type(target)~="table" then return end
    for key,value in pairs(values) do target[key]=value end
end
local function ApplyProfile(db)
    db.positions=db.positions or {}
    for key,spot in pairs(SPOTS) do
        db.positions[key]=db.positions[key] or {}
        db.positions[key].x=spot[1];db.positions[key].y=spot[2]
    end
    db.damageMode="quick";db.damageText=true;db.dpsCollapsed=true;db.compass=false
    Merge(db.nameplates,{amount="All",collision=false,stacking=false,rankColors=true,color={0.80,0.10,0.10},
        healthText="Numerical",healthFont=10,nameFont=12,width=70,height=5,abbreviate=false})
    Merge(db.chat,{backdropOpacity=0.75,editScale=1,width=330,height=130,font=14})
    Merge(db.minimap,{size=200,feather=0})
    Merge(db.dpsDisplay,{scale=0.68,backdropOpacity=0.7})
    Merge(db.action,{size=26,gap=2,cooldownFont=11,hotkeyFont=8,countFont=10})
    Merge(db.xp,{width=194,height=5})
    local frame={width=169,height=18,powerHeight=3,portrait=24,valueFont=11,nameFont=11}
    Merge(db.player,frame);Merge(db.target,frame)
    if db.player then db.player.healthArea="Left" end
    Merge(db.playerStyle,{healthText="Numerical"});Merge(db.targetStyle,{healthText="Numerical"})
    Merge(db.playerStyle,{showPortrait=true});Merge(db.targetStyle,{showPortrait=true})
    if db.sizeMatches then db.sizeMatches.player=nil end
    Merge(db.auras,{size=22,gap=2,timeFont=10,stackFont=10})
    Merge(db.debuffs,{size=22,gap=2,stackFont=10})
    -- The game's own row of spells and jewelry lies over the party frames, and the skill bar and pools show the same.
    SetCVar("hudBuild","0")
    SetCVar("hudClock","1");SetCVar("hudBosses","1");SetCVar("hudTally","1")
    SetCVar("nameplateLayout","overlap")
end
-- Profiles from earlier builds already hold these choices, with whatever was changed since.
local function Migrate(db)
    local found=false
    for key in pairs(db) do
        if type(key)=="string" and string.sub(key,1,10)=="localTweak" then found=true;db[key]=nil end
    end
    db.probeLoadout=nil;db.probePool=nil;db.probeMetres=nil;db.probeDistance=nil;db.layoutFitted=nil
    return found
end
local loader=CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent",function()
    if arg1~="nfUI" or type(nfUIDB)~="table" then return end
    local migrated=Migrate(nfUIDB)
    local version=nfUIDB.editProfile or 0
    if version>=PROFILE_VERSION then return end
    nfUIDB.editProfile=PROFILE_VERSION
    if version==0 and not migrated then ApplyProfile(nfUIDB);return end
    -- Version 2: taller enemy plates in a clearer font.
    if version<2 then Merge(nfUIDB.nameplates,{height=7,healthFont=10,nameFont=12}) end
    -- Each later step runs once, so that what the player changed afterwards stays.
    local k=(type(nfUIDB.layoutBasis)=="table" and nfUIDB.layoutBasis.height or 853.33)/853.33
    local positions=type(nfUIDB.positions)=="table" and nfUIDB.positions or {}
    -- Version 4: every health bar shows the current health, without the percentage.
    if version<4 then
        Merge(nfUIDB.playerStyle,{healthText="Numerical"});Merge(nfUIDB.targetStyle,{healthText="Numerical"})
        Merge(nfUIDB.nameplates,{healthText="Numerical"})
    end
    -- Version 5: the chat with even margins.
    if version<5 then
        Merge(nfUIDB.chat,{backdropOpacity=0.75})
        positions.chat1={x=SPOTS.chat1[1]*k,y=SPOTS.chat1[2]*k}
    end
    -- Version 6: the two pools move over the chat.
    if version<6 then positions.blockPool=nil;positions.blockJewelPool=nil end
    -- Version 17: allies' bars narrower and taller.
    if version<17 and type(nfUIDB.blocks)=="table" and nfUIDB.blocks.allyPlateWidth==150 then nfUIDB.blocks.allyPlateWidth=110 end
    -- Version 16: the panels join their groups.
    if version<16 then
        for _,key in ipairs({"blockBosses","blockLairs","blockTaken","blockHistory","blockGraph","blockStats","blockPool","blockJewelPool"}) do positions[key]=nil end
    end
    -- Version 15: a chosen ally's panel returns under the target of target.
    if version<15 then positions.blockAlly=nil end
    -- Version 14: lower enemy bars.
    if version<14 and type(nfUIDB.nameplates)=="table" and nfUIDB.nameplates.height==7 then nfUIDB.nameplates.height=5 end
    -- Version 13: an ally's panel moves under the portrait.
    if version<13 then positions.blockAlly=nil end
    -- Version 12: rising numbers travel further, so that they do not cover each other.
    if version<12 and type(nfUIDB.blocks)=="table" and nfUIDB.blocks.risingHeight==42 then nfUIDB.blocks.risingHeight=64 end
    -- Version 11: the jewelry pool is compact again, at full size.
    if version<11 and type(nfUIDB.blocks)=="table" then nfUIDB.blocks.jewelPoolScale=1 end
    -- Version 9: the game's own row of spells and jewelry goes.
    if version<9 then SetCVar("hudBuild","0") end
    -- Version 8: blocks stay chained unless dragged; opening the movers had pinned them all.
    if version<8 then
        for _,key in ipairs({"blockBosses","blockLairs","blockTaken","blockHistory","blockPool","blockJewelPool"}) do positions[key]=nil end
    end
    -- Version 7: the input above the chat's tabs, and the pools above that.
    if version<7 then
        positions.chatInput={x=SPOTS.chatInput[1]*k,y=SPOTS.chatInput[2]*k}
        positions.blockPool=nil;positions.blockJewelPool=nil
    end
end)

local function ScreenUnits()
    -- GetWidth and GetHeight leave out the UI scale; positions are laid out in the scaled units.
    local uiScale=UIParent:GetEffectiveScale()
    return UIParent:GetWidth()/uiScale,UIParent:GetHeight()/uiScale
end
-- The layout was made on a 3440x1440 screen, which is this many UI units.
local BASIS_WIDTH,BASIS_HEIGHT=2038.5,853.33
-- The edit's settings as a first start would make them, fitted to this screen. "Reset" returns to these.
function nfUIEdit.FreshProfile()
    local fresh=nfUIBuildStarterProfile(UIParent:GetWidth(),UIParent:GetHeight())
    for name,defaults in pairs(nfUIConfig.defaults) do
        if type(fresh[name])~="table" then fresh[name]={} end
        for key,value in pairs(defaults) do
            if fresh[name][key]==nil then fresh[name][key]=value end
        end
    end
    ApplyProfile(fresh)
    fresh.editProfile=PROFILE_VERSION
    local width,height=ScreenUnits()
    nfUILayoutRescale(fresh,BASIS_WIDTH,BASIS_HEIGHT,width,height)
    fresh.layoutBasis={width=width,height=height}
    return fresh
end
-- Fits the layout to any screen. Positions are kept relative to where they belong: the two central
-- blocks to the screen's centre, everything else to its nearest corner. Sizes follow the screen's height.
-- Runs again only when the screen's shape or UI scale changes, so moving things by hand is kept.
local LAYOUT_CENTERED={actionBar=true,xp=true,player=true,playerAuras=true,target=true,targetDebuffs=true}
function nfUILayoutRescale(db,oldWidth,oldHeight,width,height)
    local k=height/oldHeight
    local centered=db.layoutPreset=="classic" and CLASSIC_CENTERED or LAYOUT_CENTERED
    for key,spot in pairs(db.positions or {}) do
        if type(spot)=="table" and type(spot.x)=="number" and type(spot.y)=="number" and not spot.centered then
            if centered[key] then
                spot.x=width/2+(spot.x-oldWidth/2)*k
                spot.y=spot.y*k
            else
                if spot.x>oldWidth/2 then spot.x=width+(spot.x-oldWidth)*k else spot.x=spot.x*k end
                if spot.y>oldHeight/2 then spot.y=height+(spot.y-oldHeight)*k else spot.y=spot.y*k end
            end
        end
    end
    if db.layout and db.layout.scale then db.layout.scale=db.layout.scale*k end
    if db.minimap and db.minimap.scale then db.minimap.scale=db.minimap.scale*k end
    if db.dpsDisplay and db.dpsDisplay.scale then db.dpsDisplay.scale=db.dpsDisplay.scale*k end
    if db.micro and db.micro.scale then db.micro.scale=db.micro.scale*k end
    if db.nameplates and db.nameplates.scale then db.nameplates.scale=db.nameplates.scale*k end
    if db.chat then
        if db.chat.width then db.chat.width=db.chat.width*k end
        if db.chat.height then db.chat.height=db.chat.height*k end
        if db.chat.font then db.chat.font=math.max(10,math.floor(db.chat.font*k+0.5)) end
    end
end
-- The screen's real size can arrive only after the world loads, so it is checked once a second.
nfUIEdit.Every(1,function()
    if type(nfUIDB)~="table" or not nfUIConfig or not nfUIConfig.player then return end
    local uiScale=UIParent:GetEffectiveScale()
    if not uiScale or uiScale<=0 then return end
    local width,height=ScreenUnits()
    if not width or not height or width<=0 or height<=0 then return end
    local basis=nfUIDB.layoutBasis or {width=BASIS_WIDTH,height=BASIS_HEIGHT}
    if math.abs(basis.width-width)>2 or math.abs(basis.height-height)>2 then
        nfUILayoutRescale(nfUIDB,basis.width,basis.height,width,height)
        nfUIDB.layoutBasis={width=width,height=height}
        if nfUIConfig.Apply then pcall(nfUIConfig.Apply) end
    else
        nfUIDB.layoutBasis=basis
    end
end)

local function Copy(value)
    if type(value)~="table" then return value end
    local copy={}
    for key,item in pairs(value) do copy[key]=Copy(item) end
    return copy
end
-- "classic" puts everything where the old game had it and keeps the player's layout; "mine" brings that back.
-- A style keeps its sizes at the normal text size, so it is switched at that size and the player's text size is put back after.
local ApplyLayoutAtNormalText
function nfUIEdit.ApplyLayout(name)
    local size=nfUIEdit.TextSize and nfUIEdit.TextSize() or "normal"
    if size~="normal" and nfUIEdit.SetTextSize then nfUIEdit.SetTextSize("normal") end
    ApplyLayoutAtNormalText(name)
    if size~="normal" and nfUIEdit.SetTextSize then nfUIEdit.SetTextSize(size) end
end
ApplyLayoutAtNormalText=function(name)
    local db=nfUIDB
    if type(db)~="table" then return end
    local width,height=ScreenUnits()
    if not width or width<=0 or not height or height<=0 then return end
    db.positions=type(db.positions)=="table" and db.positions or {}
    if name=="classic" then
        if db.layoutPreset~="classic" then db.savedLayout={positions=Copy(db.positions),basis=Copy(db.layoutBasis),sizes=SizesOf(db)} end
        PutSizes(db,CLASSIC_SIZES)
        local temp={positions={},layoutPreset="classic"}
        for key,spot in pairs(SPOTS) do temp.positions[key]={x=spot[1],y=spot[2]} end
        for key,spot in pairs(CLASSIC) do temp.positions[key]={x=spot[1],y=spot[2]} end
        nfUILayoutRescale(temp,BASIS_WIDTH,BASIS_HEIGHT,width,height)
        for key,spot in pairs(temp.positions) do
            db.positions[key]=type(db.positions[key])=="table" and db.positions[key] or {}
            db.positions[key].x=spot.x;db.positions[key].y=spot.y
        end
        -- The buffs end just left of the minimap, at the top.
        local map=db.positions.minimap
        local count=table.getn(nfUIConfig.auras or {})
        local auras=type(db.auras)=="table" and db.auras or {}
        local size,gap=tonumber(auras.size) or 22,tonumber(auras.gap) or 2
        local scale=type(db.layout)=="table" and tonumber(db.layout.scale) or 1
        if map and count>0 then
            -- Below the game's kill and gold counters, which sit in the same corner.
            db.positions.playerAuras={x=math.max(4,map.x-12-count*(size+gap)*scale),y=height-40-size*scale}
        end
        db.layoutPreset="classic"
    elseif name=="mine" then
        local saved=db.savedLayout
        if type(saved)~="table" or type(saved.positions)~="table" then
            -- Nothing kept from before Classic: the edit's own layout and sizes for this screen.
            local fresh=nfUIEdit.FreshProfile()
            saved={positions=fresh.positions,basis=fresh.layoutBasis,sizes=SizesOf(fresh)}
        end
        local temp={positions=Copy(saved.positions)}
        local basis=type(saved.basis)=="table" and saved.basis or {width=width,height=height}
        if math.abs(basis.width-width)>2 or math.abs(basis.height-height)>2 then
            nfUILayoutRescale(temp,basis.width,basis.height,width,height)
        end
        db.positions=temp.positions
        PutSizes(db,saved.sizes)
        db.layoutPreset=nil
    else return end
    db.layoutBasis={width=width,height=height}
    if nfUIConfig.Apply then pcall(nfUIConfig.Apply) end
end

-- Text size: every font size the addon keeps, and its side panels, larger or smaller together.
nfUIEdit.TEXT_SIZES={{"small",0.9,"Мелкий","Small"},{"normal",1,"Обычный","Normal"},{"large",1.15,"Крупный","Large"}}
local FONT_KEYS={player={"nameFont","valueFont"},target={"nameFont","valueFont"},action={"hotkeyFont","cooldownFont","countFont"},
    auras={"timeFont","stackFont"},debuffs={"stackFont"},chat={"font","tabFont","editFont"},nameplates={"nameFont","healthFont"},
    blocks={"risingFont","skillStatsFont","metresFont","ownLevelFont"}}
local SCALE_KEYS={blocks={"groupRightScale","groupLeftScale"},dpsDisplay={"scale"}}
function nfUIEdit.TextSize() return type(nfUIDB)=="table" and nfUIDB.textSize or "normal" end
function nfUIEdit.SetTextSize(name)
    local db=nfUIDB
    if type(db)~="table" then return end
    local factor,old=nil,1
    for _,size in ipairs(nfUIEdit.TEXT_SIZES) do
        if size[1]==name then factor=size[2] end
        if size[1]==nfUIEdit.TextSize() then old=size[2] end
    end
    if not factor or factor==old then db.textSize=name;return end
    local ratio=factor/old
    for section,keys in pairs(FONT_KEYS) do
        if type(db[section])=="table" then
            for _,key in ipairs(keys) do
                local value=tonumber(db[section][key])
                if value then db[section][key]=math.floor(value*ratio+0.5) end
            end
        end
    end
    for section,keys in pairs(SCALE_KEYS) do
        if type(db[section])=="table" then
            for _,key in ipairs(keys) do
                local value=tonumber(db[section][key])
                if value then db[section][key]=value*ratio end
            end
        end
    end
    db.textSize=name
    if nfUIConfig.Apply then pcall(nfUIConfig.Apply) end
end
